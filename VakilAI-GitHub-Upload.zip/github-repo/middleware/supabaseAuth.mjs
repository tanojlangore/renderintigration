/**
 * Supabase Authentication Middleware for VakilAI
 * Replaces Firebase Admin SDK — verifies Supabase JWT tokens.
 *
 * Flow:
 *  1. Frontend signs in via Supabase (supabase.auth.signInWithPassword / signUp)
 *  2. Frontend gets session: const { data: { session } } = await supabase.auth.getSession()
 *  3. Frontend sends: Authorization: Bearer <session.access_token>
 *  4. This middleware verifies the token using Supabase Admin client
 *  5. req.user is populated with { id, email, name, role }
 */

import { createClient } from "@supabase/supabase-js";
import dotenv from "dotenv";
dotenv.config();

// ─── Supabase Admin Client (server-side, uses service role key) ───────────────
const supabaseAdmin = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY, // Never expose this to frontend!
  { auth: { autoRefreshToken: false, persistSession: false } }
);

// ─── Verify Supabase Token ────────────────────────────────────────────────────
export async function verifySupabaseToken(accessToken) {
  const { data: { user }, error } = await supabaseAdmin.auth.getUser(accessToken);
  if (error || !user) throw new Error(error?.message || "Invalid token");
  return user;
}

// ─── Get user role from DB ────────────────────────────────────────────────────
async function getUserRole(uid) {
  const { data } = await supabaseAdmin
    .from("users")
    .select("role")
    .eq("supabase_uid", uid)
    .single();
  return data?.role || "user";
}

// ─── Required Auth Middleware ─────────────────────────────────────────────────
export function requireAuth(req, res, next) {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({
      error: "Unauthorized",
      message: "Missing or invalid Authorization header. Expected: Bearer <supabase-access-token>",
    });
  }

  const accessToken = authHeader.split("Bearer ")[1];

  verifySupabaseToken(accessToken)
    .then(async (user) => {
      const role = await getUserRole(user.id);
      req.user = {
        uid: user.id,           // Supabase UUID
        email: user.email || null,
        name: user.user_metadata?.full_name || user.email?.split("@")[0] || "User",
        emailVerified: !!user.email_confirmed_at,
        role,
        _supabaseUser: user,
      };
      next();
    })
    .catch((error) => {
      console.error("[Supabase Auth] Token verification failed:", error.message);
      return res.status(401).json({
        error: "Unauthorized",
        message: "Invalid or expired token. Please sign in again.",
      });
    });
}

// ─── Optional Auth Middleware ─────────────────────────────────────────────────
export function optionalAuth(req, res, next) {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    req.user = null;
    return next();
  }

  const accessToken = authHeader.split("Bearer ")[1];

  verifySupabaseToken(accessToken)
    .then(async (user) => {
      const role = await getUserRole(user.id);
      req.user = {
        uid: user.id,
        email: user.email || null,
        name: user.user_metadata?.full_name || user.email?.split("@")[0] || "User",
        emailVerified: !!user.email_confirmed_at,
        role,
        _supabaseUser: user,
      };
      next();
    })
    .catch(() => {
      req.user = null;
      next();
    });
}

// ─── Admin Role Middleware ────────────────────────────────────────────────────
export function requireAdmin(req, res, next) {
  if (!req.user) {
    return res.status(401).json({ error: "Unauthorized", message: "Not authenticated." });
  }
  if (req.user.role !== "admin") {
    return res.status(403).json({ error: "Forbidden", message: "Admin access required." });
  }
  next();
}

// ─── Set User Role ────────────────────────────────────────────────────────────
export async function setUserRole(uid, role) {
  const { error } = await supabaseAdmin
    .from("users")
    .update({ role })
    .eq("supabase_uid", uid);
  if (error) throw new Error(error.message);
  return { success: true, uid, role };
}

export { supabaseAdmin };
export default { requireAuth, optionalAuth, requireAdmin, verifySupabaseToken, setUserRole };
