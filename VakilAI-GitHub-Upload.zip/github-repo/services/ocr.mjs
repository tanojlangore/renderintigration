/**
 * OCR Service — Extract text from images and PDFs using Tesseract
 * Supports: JPG, PNG, PDF, TIFF
 * Used for: Scanning case documents, evidence, written statements
 */

import Tesseract from "tesseract.js";
import { createWriteStream, existsSync } from "fs";
import { mkdir } from "fs/promises";
import { join } from "path";
import { fileURLToPath } from "url";
import { dirname } from "path";

const __dirname = dirname(fileURLToPath(import.meta.url));
const UPLOAD_DIR = join(__dirname, "../uploads/ocr");

// Ensure upload directory exists
if (!existsSync(UPLOAD_DIR)) {
  await mkdir(UPLOAD_DIR, { recursive: true });
}

/**
 * Extract text from image using Tesseract OCR
 * @param {string} imagePath - Path to image file
 * @param {string} language - Language code (eng, hin, mar, etc.)
 * @returns {Promise<{text: string, confidence: number, languages: string[]}>}
 */
export async function extractTextFromImage(imagePath, language = "eng") {
  try {
    console.log(`[OCR] Extracting text from ${imagePath} (language: ${language})`);

    const worker = await Tesseract.createWorker();
    await worker.loadLanguage(language);
    await worker.initialize(language);

    const result = await worker.recognize(imagePath);
    const text = result.data.text;
    const confidence = result.data.confidence;

    await worker.terminate();

    return {
      text: text.trim(),
      confidence: Math.round(confidence),
      language,
      wordsDetected: text.split(/\s+/).length,
    };
  } catch (err) {
    console.error("[OCR Error]", err);
    throw new Error(`OCR extraction failed: ${err.message}`);
  }
}

/**
 * Extract text from multiple pages of a PDF
 * For production, use pdf-parse or pdfjs-dist
 * This is a simplified version that requires pdf2image conversion first
 */
export async function extractTextFromPDF(pdfPath, language = "eng") {
  try {
    console.log(`[OCR] Extracting text from PDF ${pdfPath}`);
    // In production, use: pdf2image -> extract each page -> OCR
    // For now, throw informative error
    throw new Error("PDF OCR requires pdf2image conversion. Install: apt-get install poppler-utils");
  } catch (err) {
    console.error("[PDF OCR Error]", err);
    throw err;
  }
}

/**
 * Analyze extracted text and extract key information
 * Returns: parties, dates, incidents, evidence, etc.
 */
export function analyzeExtractedText(text) {
  const lines = text.split("\n").filter(l => l.trim());

  // Simple pattern matching for common legal document elements
  const analysis = {
    totalLines: lines.length,
    totalWords: text.split(/\s+/).length,
    hasDatePatterns: /\d{1,2}[-\/]\d{1,2}[-\/]\d{2,4}/.test(text),
    hasNamePatterns: /\b[A-Z][a-z]+ [A-Z][a-z]+\b/.test(text),
    hasSectionPatterns: /Section\s+\d+|S\.\s*\d+|IPC|BNS|CrPC|BNSS/i.test(text),
    dates: extractDates(text),
    sections: extractSections(text),
    names: extractNames(text),
    keyPhrases: extractKeyPhrases(text),
  };

  return analysis;
}

function extractDates(text) {
  const dateRegex = /\d{1,2}[-\/]\d{1,2}[-\/]\d{2,4}|\d{1,2}\s+(January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{4}/gi;
  return [...new Set(text.match(dateRegex) || [])];
}

function extractSections(text) {
  const sectionRegex = /(?:Section|S\.|Sec\.)\s+(\d+[A-Z]?)/gi;
  const matches = text.matchAll(sectionRegex);
  return [...new Set([...matches].map(m => m[1]))];
}

function extractNames(text) {
  // Simple capitalized word pairs (assumes names are capitalized)
  const nameRegex = /\b[A-Z][a-z]+ [A-Z][a-z]+\b/g;
  return [...new Set(text.match(nameRegex) || [])].slice(0, 10); // Top 10
}

function extractKeyPhrases(text) {
  const phrases = [
    "case", "incident", "accused", "victim", "witness", "evidence", "crime",
    "theft", "assault", "murder", "rape", "fraud", "cheating", "dowry",
    "bail", "arrest", "FIR", "complaint", "court", "judge", "advocate",
  ];

  const found = [];
  for (const phrase of phrases) {
    if (new RegExp(`\\b${phrase}\\b`, "i").test(text)) {
      found.push(phrase);
    }
  }
  return found;
}

export default {
  extractTextFromImage,
  extractTextFromPDF,
  analyzeExtractedText,
};
