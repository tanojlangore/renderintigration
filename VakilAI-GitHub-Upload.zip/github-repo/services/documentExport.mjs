/**
 * Indian Judiciary Document Export Service
 * Generates court-ready documents in Indian legal formats
 * Exports: Word (.docx), PDF, Plain text
 * Formats: Affidavit, Plaint, Bail Application, FIR Complaint, Written Statement
 */

import { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, AlignmentType, WidthType, BorderStyle } from "docx";
import { writeFileSync, readFileSync, unlinkSync } from "fs";
import { join } from "path";
import { fileURLToPath } from "url";
import { dirname } from "path";

const __dirname = dirname(fileURLToPath(import.meta.url));
const EXPORT_DIR = join(__dirname, "../exports");

/**
 * Generate Affidavit in Indian format
 * Used for: Bail applications, court submissions, evidence
 */
export function generateAffidavit(data) {
  const {
    deponentName,
    deponentAddress,
    deponentOccupation,
    purpose,
    facts,
    caseNumber,
    court,
    date = new Date().toLocaleDateString("en-IN"),
  } = data;

  const doc = new Document({
    sections: [{
      children: [
        // Header
        new Paragraph({
          text: "AFFIDAVIT",
          alignment: AlignmentType.CENTER,
          spacing: { after: 200 },
          run: new TextRun({ bold: true, size: 28 }),
        }),

        // Court and case info
        new Paragraph({
          text: `IN THE ${court}`,
          alignment: AlignmentType.CENTER,
          spacing: { after: 100 },
        }),
        new Paragraph({
          text: `Case No. ${caseNumber || "[Case Number]"}`,
          alignment: AlignmentType.CENTER,
          spacing: { after: 400 },
        }),

        // Main content
        new Paragraph({
          text: "I, ",
          run: new TextRun({ bold: true }),
        }),
        new Paragraph({
          text: `${deponentName}, son/daughter of _____, aged about _____ years, resident of ${deponentAddress}, by profession ${deponentOccupation || "___"}, do hereby solemnly affirm and state as follows:`,
          spacing: { after: 200 },
        }),

        // Purpose
        new Paragraph({
          text: `1. That the purpose of this affidavit is ${purpose}.`,
          spacing: { after: 200 },
        }),

        // Facts (numbered paragraphs)
        ...generateNumberedParagraphs(facts),

        // Verification
        new Paragraph({
          text: "VERIFICATION:",
          bold: true,
          spacing: { before: 400, after: 200 },
        }),
        new Paragraph({
          text: "I hereby verify that the contents of the above affidavit are true to my knowledge and belief. I have not concealed any material fact.",
          spacing: { after: 400 },
        }),

        // Signature area
        new Paragraph({
          text: `Dated this _____ day of _____, 20_____`,
          spacing: { after: 400 },
        }),
        new Paragraph({
          text: `Place: ${court}`,
          spacing: { after: 200 },
        }),
        new Paragraph({
          text: `(${deponentName})`,
          spacing: { after: 400 },
        }),

        // Advocate details
        new Paragraph({
          text: "Advocate for the Deponent",
          spacing: { before: 200 },
        }),
        new Paragraph({
          text: "Name: _____________________",
        }),
        new Paragraph({
          text: "Bar Council Reg. No.: _____________________",
        }),
      ],
    }],
  });

  return doc;
}

/**
 * Generate Plaint (Civil Suit) in Indian format
 */
export function generatePlaint(data) {
  const {
    plaintiffName,
    plaintiffAddress,
    defendantName,
    defendantAddress,
    court,
    causeOfAction,
    facts,
    relief,
    caseNumber,
    date = new Date().toLocaleDateString("en-IN"),
  } = data;

  const doc = new Document({
    sections: [{
      children: [
        new Paragraph({
          text: "PLAINT",
          alignment: AlignmentType.CENTER,
          bold: true,
          spacing: { after: 200 },
          run: new TextRun({ size: 28 }),
        }),

        new Paragraph({
          text: `IN THE ${court}`,
          alignment: AlignmentType.CENTER,
          spacing: { after: 100 },
        }),

        // Cause title
        new Paragraph({
          text: `${plaintiffName}, Plaintiff`,
          spacing: { after: 100 },
        }),
        new Paragraph({
          text: "Versus",
          alignment: AlignmentType.CENTER,
          spacing: { after: 100 },
        }),
        new Paragraph({
          text: `${defendantName}, Defendant`,
          spacing: { after: 400 },
        }),

        // Jurisdiction
        new Paragraph({
          text: "1. JURISDICTION:",
          bold: true,
          spacing: { after: 100 },
        }),
        new Paragraph({
          text: `This court has jurisdiction to entertain this suit as the cause of action wholly arose within the jurisdiction of this court.`,
          spacing: { after: 200 },
        }),

        // Parties
        new Paragraph({
          text: "2. PARTIES:",
          bold: true,
          spacing: { after: 100 },
        }),
        new Paragraph({
          text: `Plaintiff: ${plaintiffName}, resident of ${plaintiffAddress}`,
          spacing: { after: 100 },
        }),
        new Paragraph({
          text: `Defendant: ${defendantName}, resident of ${defendantAddress}`,
          spacing: { after: 200 },
        }),

        // Cause of action
        new Paragraph({
          text: "3. CAUSE OF ACTION:",
          bold: true,
          spacing: { after: 100 },
        }),
        new Paragraph({
          text: causeOfAction,
          spacing: { after: 200 },
        }),

        // Facts
        new Paragraph({
          text: "4. FACTS:",
          bold: true,
          spacing: { after: 100 },
        }),
        ...generateNumberedParagraphs(facts, 4),

        // Relief
        new Paragraph({
          text: "5. PRAYER:",
          bold: true,
          spacing: { before: 200, after: 100 },
        }),
        new Paragraph({
          text: relief,
          spacing: { after: 400 },
        }),

        // Verification
        new Paragraph({
          text: "VERIFICATION:",
          bold: true,
          spacing: { after: 100 },
        }),
        new Paragraph({
          text: `I, ${plaintiffName}, do hereby verify that the contents of this plaint are true to my knowledge and belief.`,
          spacing: { after: 400 },
        }),

        new Paragraph({
          text: `Dated: ${date}`,
          spacing: { after: 200 },
        }),
        new Paragraph({
          text: `(${plaintiffName})`,
        }),
      ],
    }],
  });

  return doc;
}

/**
 * Generate Bail Application in Indian format
 */
export function generateBailApplication(data) {
  const {
    applicantName,
    applicantAddress,
    offence,
    sections,
    court,
    facts,
    grounds,
    date = new Date().toLocaleDateString("en-IN"),
  } = data;

  const doc = new Document({
    sections: [{
      children: [
        new Paragraph({
          text: "BAIL APPLICATION",
          alignment: AlignmentType.CENTER,
          bold: true,
          spacing: { after: 200 },
          run: new TextRun({ size: 28 }),
        }),

        new Paragraph({
          text: `IN THE ${court}`,
          alignment: AlignmentType.CENTER,
          spacing: { after: 100 },
        }),

        new Paragraph({
          text: `Applicant: ${applicantName}`,
          spacing: { after: 200 },
        }),

        new Paragraph({
          text: "TO THE HON'BLE COURT,",
          spacing: { after: 200 },
        }),

        new Paragraph({
          text: "The applicant humbly submits as follows:",
          spacing: { after: 200 },
        }),

        // Offence details
        new Paragraph({
          text: "1. OFFENCE AND CHARGES:",
          bold: true,
          spacing: { after: 100 },
        }),
        new Paragraph({
          text: `The applicant has been charged with ${offence} under Section(s) ${sections} of the Indian Penal Code.`,
          spacing: { after: 200 },
        }),

        // Facts
        new Paragraph({
          text: "2. FACTS:",
          bold: true,
          spacing: { after: 100 },
        }),
        ...generateNumberedParagraphs(facts, 2),

        // Grounds for bail
        new Paragraph({
          text: "3. GROUNDS FOR BAIL:",
          bold: true,
          spacing: { before: 200, after: 100 },
        }),
        new Paragraph({
          text: grounds,
          spacing: { after: 200 },
        }),

        // Prayer
        new Paragraph({
          text: "4. PRAYER:",
          bold: true,
          spacing: { after: 100 },
        }),
        new Paragraph({
          text: "It is therefore prayed that this Hon'ble Court be pleased to grant bail to the applicant on such terms and conditions as this Court deems fit.",
          spacing: { after: 400 },
        }),

        new Paragraph({
          text: `Dated: ${date}`,
          spacing: { after: 200 },
        }),
        new Paragraph({
          text: `(${applicantName})`,
        }),
      ],
    }],
  });

  return doc;
}

/**
 * Generate FIR Complaint in Indian format
 */
export function generateFIRComplaint(data) {
  const {
    complainantName,
    complainantAddress,
    policeStation,
    offence,
    sections,
    incidentDate,
    incidentPlace,
    facts,
    date = new Date().toLocaleDateString("en-IN"),
  } = data;

  const doc = new Document({
    sections: [{
      children: [
        new Paragraph({
          text: "COMPLAINT FOR FIR REGISTRATION",
          alignment: AlignmentType.CENTER,
          bold: true,
          spacing: { after: 200 },
          run: new TextRun({ size: 28 }),
        }),

        new Paragraph({
          text: `Police Station: ${policeStation}`,
          spacing: { after: 200 },
        }),

        new Paragraph({
          text: "TO THE OFFICER IN CHARGE,",
          spacing: { after: 200 },
        }),

        // Complainant details
        new Paragraph({
          text: "1. COMPLAINANT DETAILS:",
          bold: true,
          spacing: { after: 100 },
        }),
        new Paragraph({
          text: `Name: ${complainantName}`,
          spacing: { after: 50 },
        }),
        new Paragraph({
          text: `Address: ${complainantAddress}`,
          spacing: { after: 200 },
        }),

        // Offence details
        new Paragraph({
          text: "2. OFFENCE DETAILS:",
          bold: true,
          spacing: { after: 100 },
        }),
        new Paragraph({
          text: `Offence: ${offence}`,
          spacing: { after: 50 },
        }),
        new Paragraph({
          text: `Applicable Sections: ${sections}`,
          spacing: { after: 50 },
        }),
        new Paragraph({
          text: `Date of Incident: ${incidentDate}`,
          spacing: { after: 50 },
        }),
        new Paragraph({
          text: `Place of Incident: ${incidentPlace}`,
          spacing: { after: 200 },
        }),

        // Facts
        new Paragraph({
          text: "3. FACTS OF THE CASE:",
          bold: true,
          spacing: { after: 100 },
        }),
        ...generateNumberedParagraphs(facts, 3),

        // Prayer
        new Paragraph({
          text: "4. PRAYER:",
          bold: true,
          spacing: { before: 200, after: 100 },
        }),
        new Paragraph({
          text: "I request that a First Information Report (FIR) be registered against the accused person(s) and necessary investigation be conducted.",
          spacing: { after: 400 },
        }),

        new Paragraph({
          text: `Dated: ${date}`,
          spacing: { after: 200 },
        }),
        new Paragraph({
          text: `(${complainantName})`,
        }),
      ],
    }],
  });

  return doc;
}

/**
 * Helper: Generate numbered paragraphs from text
 */
function generateNumberedParagraphs(text, startNumber = 1) {
  if (!text) return [];

  const paragraphs = text.split("\n").filter(p => p.trim());
  return paragraphs.map((para, idx) => {
    return new Paragraph({
      text: `${startNumber + idx}. ${para.trim()}`,
      spacing: { after: 100 },
    });
  });
}

/**
 * Export document to Word format (.docx)
 */
export async function exportToWord(docxDocument, filename) {
  try {
    const buffer = await Packer.toBuffer(docxDocument);
    const filepath = join(EXPORT_DIR, filename);
    writeFileSync(filepath, buffer);
    return filepath;
  } catch (err) {
    throw new Error(`Failed to export to Word: ${err.message}`);
  }
}

/**
 * Export document to plain text
 */
export function exportToText(docxDocument, filename) {
  try {
    // Simple text extraction from docx
    const text = extractTextFromDocx(docxDocument);
    const filepath = join(EXPORT_DIR, filename);
    writeFileSync(filepath, text, "utf-8");
    return filepath;
  } catch (err) {
    throw new Error(`Failed to export to text: ${err.message}`);
  }
}

/**
 * Helper: Extract text from docx document
 */
function extractTextFromDocx(doc) {
  let text = "";
  if (doc.sections) {
    doc.sections.forEach(section => {
      if (section.children) {
        section.children.forEach(child => {
          if (child.text) text += child.text + "\n";
        });
      }
    });
  }
  return text;
}

export default {
  generateAffidavit,
  generatePlaint,
  generateBailApplication,
  generateFIRComplaint,
  exportToWord,
  exportToText,
};
