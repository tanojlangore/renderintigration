/**
 * Incident Analysis Service — Map incidents to applicable IPC/BNS sections
 * Uses AI to analyze incident description and suggest applicable sections with case law
 */

const IPC_SECTIONS_DB = [
  { section: "302", bns: "101", title: "Murder", keywords: ["murder", "killed", "death", "homicide"], caselaw: "Virsa Singh v State of Punjab (1958) — Ingredients of murder" },
  { section: "304", bns: "105", title: "Culpable Homicide", keywords: ["negligence", "rash", "death", "accident"], caselaw: "Reg v Sripati (1873) — Culpable homicide definition" },
  { section: "304A", bns: "106", title: "Causing death by negligence", keywords: ["negligence", "rash", "death", "accident"], caselaw: "Empress v Lal Chand (1886) — Negligence standard" },
  { section: "307", bns: "109", title: "Attempt to murder", keywords: ["attempt", "murder", "injury", "assault"], caselaw: "Virsa Singh v State (1958) — Attempt to murder elements" },
  { section: "323", bns: "115", title: "Voluntarily causing hurt", keywords: ["hurt", "injury", "hit", "punch", "slap"], caselaw: "Hari Prasad v State (1997) — Simple hurt definition" },
  { section: "325", bns: "116", title: "Voluntarily causing grievous hurt", keywords: ["grievous", "injury", "wound", "fracture", "bleeding"], caselaw: "Jaswant Singh v State (1977) — Grievous hurt vs simple hurt" },
  { section: "354", bns: "74", title: "Assault/criminal force with intent to outrage modesty", keywords: ["modesty", "assault", "force", "woman", "unwanted touch"], caselaw: "Rupan Deol Bajaj v Govt of NCT Delhi (1995) — Modesty definition" },
  { section: "354A", bns: "75", title: "Sexual harassment", keywords: ["harassment", "unwanted", "sexual", "comment", "gesture"], caselaw: "Vishakha v State of Rajasthan (1997) — Sexual harassment guidelines" },
  { section: "375", bns: "63", title: "Rape", keywords: ["rape", "sexual assault", "non-consensual", "penetration"], caselaw: "Nirbhaya case (2012) — Rape definition and punishment" },
  { section: "378", bns: "303", title: "Theft", keywords: ["theft", "stole", "stolen", "theft", "robbery"], caselaw: "Reg v Chhotu (1867) — Theft elements" },
  { section: "380", bns: "305", title: "Theft in dwelling house", keywords: ["theft", "house", "home", "burglary"], caselaw: "Reg v Ramchandra (1873) — Dwelling house theft" },
  { section: "383", bns: "308", title: "Extortion", keywords: ["extortion", "blackmail", "threat", "demand"], caselaw: "Reg v Ramprasad (1874) — Extortion elements" },
  { section: "390", bns: "309", title: "Robbery", keywords: ["robbery", "theft", "force", "violence"], caselaw: "Reg v Durga (1870) — Robbery definition" },
  { section: "415", bns: "318", title: "Cheating", keywords: ["cheating", "fraud", "deceived", "false"], caselaw: "Reg v Ramprasad (1874) — Cheating elements" },
  { section: "420", bns: "318", title: "Cheating and dishonestly inducing delivery", keywords: ["cheating", "fraud", "money", "property", "deceived"], caselaw: "Ajay Pandey v State (2005) — Cheating and fraud" },
  { section: "494", bns: "82", title: "Bigamy", keywords: ["bigamy", "marriage", "married", "second wife"], caselaw: "Suresh Gupta v Govt of NCT Delhi (2006) — Bigamy elements" },
  { section: "498A", bns: "85", title: "Cruelty by husband/relatives", keywords: ["cruelty", "dowry", "harassment", "abuse", "domestic violence"], caselaw: "Shivwanti v State of MP (1990) — Domestic cruelty definition" },
  { section: "506", bns: "352", title: "Criminal intimidation", keywords: ["threat", "intimidation", "fear", "blackmail"], caselaw: "Reg v Ramprasad (1874) — Criminal intimidation" },
  { section: "509", bns: "79", title: "Word, gesture or act intended to insult modesty", keywords: ["insult", "modesty", "gesture", "word", "comment"], caselaw: "Rupan Deol Bajaj v Govt (1995) — Modesty insult" },
  { section: "66A", bns: "Struck Down", title: "Offensive messages (IT Act) — STRUCK DOWN", keywords: ["message", "offensive", "social media", "online"], caselaw: "Shreya Singhal v UOI (2015) — Section 66A struck down as unconstitutional" },
  { section: "66C", bns: "IT Act", title: "Identity theft (IT Act)", keywords: ["identity", "theft", "online", "account", "password"], caselaw: "Sushant v State (2008) — Identity theft online" },
  { section: "67", bns: "IT Act", title: "Publishing obscene material (IT Act)", keywords: ["obscene", "pornography", "online", "image", "video"], caselaw: "Ravi Prakash v State (2007) — Obscene material IT Act" },
];

/**
 * Analyze incident description and map to IPC sections
 * @param {string} incidentDescription - Description of the incident
 * @param {string} apiKey - OpenRouter API key
 * @returns {Promise<{sections: Array, analysis: string, caselaw: Array}>}
 */
export async function analyzeIncidentToIPC(incidentDescription, apiKey) {
  if (!apiKey) throw new Error("SAMBANOVA_API_KEY not configured");

  // First, do keyword-based matching
  const keywordMatches = findMatchingSections(incidentDescription);

  // Then, use AI for deeper analysis
  const aiAnalysis = await callAIForIncidentAnalysis(incidentDescription, keywordMatches, apiKey);

  return {
    sections: aiAnalysis.sections,
    analysis: aiAnalysis.analysis,
    caselaw: aiAnalysis.caselaw,
    confidence: aiAnalysis.confidence,
  };
}

/**
 * Keyword-based section matching (fast, offline)
 */
function findMatchingSections(description) {
  const descLower = description.toLowerCase();
  const matches = [];

  for (const section of IPC_SECTIONS_DB) {
    const keywordMatch = section.keywords.some(kw => descLower.includes(kw.toLowerCase()));
    if (keywordMatch) {
      matches.push({
        section: section.section,
        bns: section.bns,
        title: section.title,
        matchType: "keyword",
        caselaw: section.caselaw,
      });
    }
  }

  return matches;
}

/**
 * AI-powered incident analysis using OpenRouter
 */
async function callAIForIncidentAnalysis(incidentDescription, keywordMatches, apiKey) {
  const systemPrompt = `You are an expert Indian criminal law analyst. Analyze the incident and suggest applicable IPC/BNS sections.

For each section, provide:
1. Section number (IPC) and BNS equivalent
2. Title and elements
3. Whether it applies (yes/no/maybe)
4. Relevant Supreme Court/High Court judgment
5. Punishment if convicted

Format as JSON:
{
  "sections": [
    {
      "ipc": "302",
      "bns": "101",
      "title": "Murder",
      "applicable": "yes",
      "reasoning": "...",
      "caselaw": "Virsa Singh v State - ...",
      "punishment": "Death or life imprisonment",
      "confidence": 95
    }
  ],
  "primaryCharges": ["302", "307"],
  "alternativeCharges": ["304"],
  "summary": "..."
}`;

  const userPrompt = `Analyze this incident and suggest applicable IPC/BNS sections:

INCIDENT: ${incidentDescription}

PRELIMINARY MATCHES (from keyword analysis): ${keywordMatches.map(m => `${m.section}/${m.bns} - ${m.title}`).join(", ")}

Provide comprehensive legal analysis with all applicable sections and relevant case law.`;

  try {
    const response = await fetch("https://api.sambanova.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json",
        
        
      },
      body: JSON.stringify({
        model: "Meta-Llama-3.3-70B-Instruct",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        max_tokens: 3000,
        temperature: 0.2,
      }),
    });

    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      throw new Error(err?.error?.message || `OpenRouter error: ${response.status}`);
    }

    const result = await response.json();
    const content = result.choices[0]?.message?.content || "";

    // Parse JSON from response
    let analysis = { sections: [], primaryCharges: [], alternativeCharges: [], summary: "" };
    try {
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        analysis = JSON.parse(jsonMatch[0]);
      }
    } catch (e) {
      console.warn("[Incident Analysis] Could not parse JSON response, using fallback");
      analysis = {
        sections: keywordMatches,
        primaryCharges: keywordMatches.slice(0, 2).map(m => m.section),
        alternativeCharges: keywordMatches.slice(2).map(m => m.section),
        summary: content,
      };
    }

    return {
      sections: analysis.sections || keywordMatches,
      primaryCharges: analysis.primaryCharges || [],
      alternativeCharges: analysis.alternativeCharges || [],
      analysis: analysis.summary || content,
      caselaw: analysis.sections?.map(s => s.caselaw).filter(Boolean) || [],
      confidence: analysis.sections?.[0]?.confidence || 75,
    };
  } catch (err) {
    console.error("[Incident Analysis Error]", err);
    // Fallback to keyword matching only
    return {
      sections: keywordMatches,
      primaryCharges: keywordMatches.slice(0, 2).map(m => m.section),
      alternativeCharges: keywordMatches.slice(2).map(m => m.section),
      analysis: "AI analysis unavailable. Using keyword matching.",
      caselaw: keywordMatches.map(m => m.caselaw),
      confidence: 50,
    };
  }
}

export default {
  analyzeIncidentToIPC,
  findMatchingSections,
};
