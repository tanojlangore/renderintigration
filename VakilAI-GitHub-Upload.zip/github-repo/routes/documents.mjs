/**
 * Documents Routes — AI-powered legal document generation
 * GET    /api/documents           — List user's documents
 * POST   /api/documents           — Save a document
 * GET    /api/documents/:id       — Get document
 * DELETE /api/documents/:id       — Delete document
 * POST   /api/documents/generate  — AI-generate a legal document
 */

import { Router } from "express";
import { requireAuth } from "../middleware/supabaseAuth.mjs";
import { db } from "../server.mjs";

const router = Router();

// ─── Document Templates ───────────────────────────────────────────────────────
const DOCUMENT_PROMPTS = {
  bail_application: (data) => `Draft a formal bail application under Section 437/439 CrPC (or equivalent BNSS section) for the following case:
Accused: ${data.accusedName}
Offence: ${data.offence} (Section ${data.sections})
Court: ${data.court}
Facts: ${data.facts}
Grounds for bail: ${data.grounds || "First offender, no criminal antecedents, willing to cooperate with investigation"}
Include: Cause title, facts of the case, legal grounds, prayer for bail, verification.`,

  fir_complaint: (data) => `Draft a formal FIR complaint/complaint petition for:
Complainant: ${data.complainantName}
Against: ${data.accusedName}
Offence: ${data.offence}
Date/Time/Place: ${data.incident}
Facts: ${data.facts}
Include: Proper format, all relevant IPC/BNS sections, prayer for FIR registration.`,

  legal_notice: (data) => `Draft a formal legal notice under Indian law:
From: ${data.senderName} (through Advocate)
To: ${data.recipientName}
Subject: ${data.subject}
Facts: ${data.facts}
Relief sought: ${data.relief}
Include: 15/30 day response period, consequences of non-compliance, proper legal format.`,

  vakalatnama: (data) => `Draft a Vakalatnama (Power of Attorney for legal representation) for:
Client: ${data.clientName}
Advocate: ${data.advocateName}
Bar Council No: ${data.barCouncilNo || "[Bar Council No.]"}
Court: ${data.court}
Case: ${data.caseTitle || "All matters"}
Include: Full vakalatnama format as per court rules.`,

  written_statement: (data) => `Draft a written statement (reply/defence) for:
Defendant: ${data.defendantName}
Plaintiff: ${data.plaintiffName}
Case: ${data.caseTitle}
Court: ${data.court}
Facts of the case: ${data.facts}
Defence: ${data.defence}
Include: Preliminary objections, reply to each paragraph, specific denials, affirmative defences, prayer.`,

  anticipatory_bail: (data) => `Draft an anticipatory bail application under Section 438 CrPC (or BNSS equivalent) for:
Applicant: ${data.applicantName}
Apprehension of arrest in: ${data.offence} (Section ${data.sections})
Facts: ${data.facts}
Grounds: ${data.grounds || "No criminal antecedents, willing to cooperate, no flight risk"}
Include: Cause title, apprehension of arrest, legal grounds under Section 438, prayer.`,

  affidavit: (data) => `Draft a formal affidavit for:
Deponent: ${data.deponentName}
Purpose: ${data.purpose}
Facts to be deposed: ${data.facts}
Include: Proper affidavit format, verification clause, oath statement as per Indian law.`,

  plaint: (data) => `Draft a civil plaint (suit) for:
Plaintiff: ${data.plaintiffName}
Defendant: ${data.defendantName}
Court: ${data.court}
Cause of action: ${data.causeOfAction}
Facts: ${data.facts}
Relief sought: ${data.relief}
Include: Jurisdiction, limitation, cause title, numbered paragraphs, prayer, verification.`,

  defence_strategy: (data) => `Prepare a comprehensive defence strategy for:
Accused: ${data.accusedName}
Charges: ${data.charges} (Sections: ${data.sections})
Court: ${data.court}
Facts as per prosecution: ${data.prosecutionFacts}
Facts as per defence: ${data.defenceFacts}
Include: Legal analysis, applicable sections, landmark judgments, bail strategy, trial strategy, cross-examination points, arguments for acquittal.`,

  quashing_petition: (data) => `Draft a petition for quashing of FIR/proceedings under Section 482 CrPC (or BNSS) for:
Petitioner: ${data.petitionerName}
FIR No: ${data.firNumber}
Police Station: ${data.policeStation}
Offence: ${data.offence}
Grounds for quashing: ${data.grounds}
Include: Jurisdiction under Section 482, grounds for quashing, relevant Supreme Court judgments, prayer.`,
};

// ─── AI Generate Document ─────────────────────────────────────────────────────
router.post("/generate", requireAuth, async (req, res) => {
  try {
    const { documentType, data, language = "english" } = req.body;

    if (!documentType || !DOCUMENT_PROMPTS[documentType]) {
      return res.status(400).json({
        error: "Invalid document type",
        validTypes: Object.keys(DOCUMENT_PROMPTS),
      });
    }

    const prompt = DOCUMENT_PROMPTS[documentType](data || {});
    const langInstruction = language === "marathi"
      ? "\n\nIMPORTANT: Draft this document in Marathi (मराठी) using proper legal Marathi terminology."
      : "";

    const apiKey = process.env.SAMBANOVA_API_KEY;
    if (!apiKey) throw new Error("SAMBANOVA_API_KEY not configured");

    const response = await fetch("https://api.sambanova.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json",
        
        
      },
      body: JSON.stringify({
        model: process.env.SAMBANOVA_MODEL || "Meta-Llama-3.3-70B-Instruct",
        messages: [
          {
            role: "system",
            content: "You are an expert Indian legal document drafter with 30+ years of experience. You draft precise, court-ready legal documents following Indian court formats and procedures. Always include proper cause title, numbered paragraphs, and prayer clause.",
          },
          { role: "user", content: prompt + langInstruction },
        ],
        max_tokens: 6000,
        temperature: 0.2,
      }),
    });

    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      throw new Error(err?.error?.message || `OpenRouter error: ${response.status}`);
    }

    const result = await response.json();
    const content = result.choices[0]?.message?.content || "";

    // Log usage
    await db.from("usage_logs").insert({
      supabase_uid: req.user.uid,
      action: "document_generate",
      tokens_used: result.usage?.total_tokens || 0,
      model_used: result.model,
    });

    res.json({ content, documentType, model: result.model, tokensUsed: result.usage?.total_tokens || 0 });
  } catch (err) {
    console.error("[Document Generate]", err);
    res.status(500).json({ error: err.message });
  }
});

// ─── List Documents ───────────────────────────────────────────────────────────
router.get("/", requireAuth, async (req, res) => {
  try {
    const { caseId, type, page = 1, limit = 20 } = req.query;
    const offset = (parseInt(page) - 1) * parseInt(limit);

    let query = db
      .from("documents")
      .select("id, title, document_type, case_id, created_at, updated_at")
      .eq("supabase_uid", req.user.uid)
      .order("updated_at", { ascending: false })
      .range(offset, offset + parseInt(limit) - 1);

    if (caseId) query = query.eq("case_id", caseId);
    if (type) query = query.eq("document_type", type);

    const { data, error } = await query;
    if (error) throw new Error(error.message);
    res.json({ documents: data });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── Save Document ────────────────────────────────────────────────────────────
router.post("/", requireAuth, async (req, res) => {
  try {
    const { title, documentType, content, caseId } = req.body;
    if (!title || !content) return res.status(400).json({ error: "title and content are required" });

    const { data, error } = await db
      .from("documents")
      .insert({
        supabase_uid: req.user.uid,
        title,
        document_type: documentType || "other",
        content,
        case_id: caseId || null,
      })
      .select("id, title, document_type")
      .single();

    if (error) throw new Error(error.message);
    res.status(201).json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── Get Document ─────────────────────────────────────────────────────────────
router.get("/:id", requireAuth, async (req, res) => {
  try {
    const { data, error } = await db
      .from("documents")
      .select("*")
      .eq("id", req.params.id)
      .eq("supabase_uid", req.user.uid)
      .single();

    if (error || !data) return res.status(404).json({ error: "Document not found" });
    res.json({ document: data });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── Delete Document ──────────────────────────────────────────────────────────
router.delete("/:id", requireAuth, async (req, res) => {
  try {
    const { error } = await db
      .from("documents")
      .delete()
      .eq("id", req.params.id)
      .eq("supabase_uid", req.user.uid);

    if (error) throw new Error(error.message);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
