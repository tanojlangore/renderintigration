/**
 * Cases Routes
 * GET    /api/cases           — List user's cases
 * POST   /api/cases           — Create new case
 * GET    /api/cases/:id       — Get case details
 * PUT    /api/cases/:id       — Update case
 * DELETE /api/cases/:id       — Archive case
 */

import { Router } from "express";
import { requireAuth } from "../middleware/supabaseAuth.mjs";
import { db } from "../server.mjs";

const router = Router();

router.get("/", requireAuth, async (req, res) => {
  try {
    const { status, type, search, page = 1, limit = 20 } = req.query;
    const offset = (parseInt(page) - 1) * parseInt(limit);

    let query = db
      .from("cases")
      .select("*", { count: "exact" })
      .eq("supabase_uid", req.user.uid)
      .order("updated_at", { ascending: false })
      .range(offset, offset + parseInt(limit) - 1);

    if (status) query = query.eq("status", status);
    if (type) query = query.eq("case_type", type);
    if (search) query = query.or(`title.ilike.%${search}%,case_number.ilike.%${search}%,client_name.ilike.%${search}%`);

    const { data, error, count } = await query;
    if (error) throw new Error(error.message);

    res.json({ cases: data, total: count, page: parseInt(page), limit: parseInt(limit) });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/", requireAuth, async (req, res) => {
  try {
    const { title, caseNumber, caseType, clientName, opposingParty, court, judge, nextHearing, description, sections } = req.body;
    if (!title || !caseType) return res.status(400).json({ error: "title and caseType are required" });

    const { data, error } = await db
      .from("cases")
      .insert({
        supabase_uid: req.user.uid,
        title,
        case_number: caseNumber,
        case_type: caseType,
        client_name: clientName,
        opposing_party: opposingParty,
        court,
        judge,
        next_hearing: nextHearing,
        description,
        sections: sections ? JSON.stringify(sections) : null,
      })
      .select()
      .single();

    if (error) throw new Error(error.message);
    res.status(201).json({ case: data });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/:id", requireAuth, async (req, res) => {
  try {
    const { data, error } = await db
      .from("cases")
      .select("*")
      .eq("id", req.params.id)
      .eq("supabase_uid", req.user.uid)
      .single();

    if (error || !data) return res.status(404).json({ error: "Case not found" });
    res.json({ case: data });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.put("/:id", requireAuth, async (req, res) => {
  try {
    const { title, caseNumber, caseType, clientName, opposingParty, court, judge, nextHearing, description, sections, status } = req.body;

    const { data, error } = await db
      .from("cases")
      .update({
        title, case_number: caseNumber, case_type: caseType, client_name: clientName,
        opposing_party: opposingParty, court, judge, next_hearing: nextHearing,
        description, sections: sections ? JSON.stringify(sections) : undefined, status,
      })
      .eq("id", req.params.id)
      .eq("supabase_uid", req.user.uid)
      .select()
      .single();

    if (error) throw new Error(error.message);
    res.json({ case: data });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.delete("/:id", requireAuth, async (req, res) => {
  try {
    const { error } = await db
      .from("cases")
      .update({ status: "archived" })
      .eq("id", req.params.id)
      .eq("supabase_uid", req.user.uid);

    if (error) throw new Error(error.message);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
