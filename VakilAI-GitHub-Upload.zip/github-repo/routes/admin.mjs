/**
 * Admin Routes — Platform management
 * GET  /api/admin/stats      — Platform statistics
 * GET  /api/admin/users      — List all users
 * POST /api/admin/users/role — Update user role
 */

import { Router } from "express";
import { requireAuth, requireAdmin } from "../middleware/supabaseAuth.mjs";
import { db } from "../server.mjs";

const router = Router();

router.get("/stats", requireAuth, requireAdmin, async (req, res) => {
  try {
    const [
      { count: totalUsers },
      { count: totalCases },
      { count: totalDocuments },
      { count: totalSessions },
      { count: activeSubscriptions },
    ] = await Promise.all([
      db.from("users").select("id", { count: "exact", head: true }),
      db.from("cases").select("id", { count: "exact", head: true }),
      db.from("documents").select("id", { count: "exact", head: true }),
      db.from("chat_sessions").select("id", { count: "exact", head: true }),
      db.from("subscriptions").select("id", { count: "exact", head: true }).eq("status", "active"),
    ]);

    res.json({ totalUsers, totalCases, totalDocuments, totalSessions, activeSubscriptions });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/users", requireAuth, requireAdmin, async (req, res) => {
  try {
    const { data, error } = await db
      .from("users")
      .select("id, supabase_uid, email, name, role, created_at, last_signed_in")
      .order("created_at", { ascending: false })
      .limit(100);

    if (error) throw new Error(error.message);
    res.json({ users: data });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/users/role", requireAuth, requireAdmin, async (req, res) => {
  try {
    const { supabaseUid, role } = req.body;
    if (!supabaseUid || !["user", "admin"].includes(role)) {
      return res.status(400).json({ error: "Invalid supabaseUid or role" });
    }
    const { error } = await db
      .from("users")
      .update({ role })
      .eq("supabase_uid", supabaseUid);

    if (error) throw new Error(error.message);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
