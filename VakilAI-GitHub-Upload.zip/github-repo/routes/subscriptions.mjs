/**
 * Subscription Routes — Plan management (Razorpay-ready)
 * GET  /api/subscriptions/plans            — List available plans
 * GET  /api/subscriptions/my              — Get user's current subscription
 * POST /api/subscriptions/razorpay/order  — Create Razorpay order
 * POST /api/subscriptions/razorpay/verify — Verify Razorpay payment
 */

import { Router } from "express";
import { requireAuth } from "../middleware/supabaseAuth.mjs";
import { db } from "../server.mjs";
import crypto from "crypto";

const router = Router();

const PLANS = [
  {
    id: "free",
    name: "Free Trial",
    price: 0,
    currency: "INR",
    period: "forever",
    features: ["5 AI chat messages/day", "2 document drafts/month", "IPC/BNS reference browser", "Basic case management (3 cases)"],
    limits: { chatMessages: 5, documents: 2, cases: 3 },
    popular: false,
  },
  {
    id: "starter",
    name: "Starter",
    price: 999,
    currency: "INR",
    period: "month",
    features: ["50 AI chat messages/day", "20 document drafts/month", "All 10 document types", "Unlimited cases", "IPC/BNS + precedent search", "Email support"],
    limits: { chatMessages: 50, documents: 20, cases: -1 },
    popular: false,
  },
  {
    id: "professional",
    name: "Professional",
    price: 2499,
    currency: "INR",
    period: "month",
    features: ["Unlimited AI chat", "Unlimited document drafts", "All document types + templates", "Unlimited cases", "Priority support", "Export to PDF/Word", "Marathi language support"],
    limits: { chatMessages: -1, documents: -1, cases: -1 },
    popular: true,
  },
  {
    id: "enterprise",
    name: "Enterprise",
    price: 7999,
    currency: "INR",
    period: "month",
    features: ["Everything in Professional", "5 team members", "Custom AI training", "Dedicated account manager", "API access", "White-label option", "SLA guarantee", "GST invoice"],
    limits: { chatMessages: -1, documents: -1, cases: -1 },
    popular: false,
  },
];

router.get("/plans", (req, res) => {
  res.json({ plans: PLANS });
});

router.get("/my", requireAuth, async (req, res) => {
  try {
    const { data, error } = await db
      .from("subscriptions")
      .select("*")
      .eq("supabase_uid", req.user.uid)
      .eq("status", "active")
      .order("created_at", { ascending: false })
      .limit(1)
      .single();

    if (error || !data) {
      return res.json({ subscription: null, plan: PLANS[0] });
    }

    const plan = PLANS.find((p) => p.id === data.plan_id) || PLANS[0];
    res.json({ subscription: data, plan });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── Create Razorpay Order ────────────────────────────────────────────────────
router.post("/razorpay/order", requireAuth, async (req, res) => {
  try {
    const { planId } = req.body;
    const plan = PLANS.find((p) => p.id === planId);
    if (!plan || plan.price === 0) return res.status(400).json({ error: "Invalid plan" });

    const razorpayKeyId = process.env.RAZORPAY_KEY_ID;
    const razorpayKeySecret = process.env.RAZORPAY_KEY_SECRET;

    if (!razorpayKeyId || !razorpayKeySecret) {
      return res.status(503).json({ error: "Payment gateway not configured. Contact support." });
    }

    const orderData = {
      amount: plan.price * 100,
      currency: "INR",
      receipt: `vakil_${req.user.uid.slice(0, 8)}_${Date.now()}`,
      notes: { planId, userUid: req.user.uid, userEmail: req.user.email },
    };

    const response = await fetch("https://api.razorpay.com/v1/orders", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Basic ${Buffer.from(`${razorpayKeyId}:${razorpayKeySecret}`).toString("base64")}`,
      },
      body: JSON.stringify(orderData),
    });

    const order = await response.json();
    if (!response.ok) throw new Error(order.error?.description || "Razorpay order creation failed");

    res.json({ orderId: order.id, amount: order.amount, currency: order.currency, keyId: razorpayKeyId });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── Verify Razorpay Payment ──────────────────────────────────────────────────
router.post("/razorpay/verify", requireAuth, async (req, res) => {
  try {
    const { orderId, paymentId, signature, planId } = req.body;
    const razorpayKeySecret = process.env.RAZORPAY_KEY_SECRET;
    if (!razorpayKeySecret) return res.status(503).json({ error: "Payment gateway not configured" });

    const expectedSignature = crypto
      .createHmac("sha256", razorpayKeySecret)
      .update(`${orderId}|${paymentId}`)
      .digest("hex");

    if (expectedSignature !== signature) {
      return res.status(400).json({ error: "Payment verification failed. Invalid signature." });
    }

    const expiresAt = new Date();
    expiresAt.setMonth(expiresAt.getMonth() + 1);

    const { error } = await db.from("subscriptions").upsert(
      {
        supabase_uid: req.user.uid,
        plan_id: planId,
        status: "active",
        payment_id: paymentId,
        order_id: orderId,
        expires_at: expiresAt.toISOString(),
      },
      { onConflict: "supabase_uid" }
    );

    if (error) throw new Error(error.message);
    res.json({ success: true, message: "Subscription activated successfully!", expiresAt });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
