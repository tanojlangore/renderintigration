/**
 * IPC/BNS Reference Routes
 * GET  /api/ipc/sections     — List all IPC/BNS sections
 * GET  /api/ipc/search       — Search sections by keyword
 * POST /api/ipc/explain      — AI explanation of a section
 */

import { Router } from "express";
import { requireAuth } from "../middleware/supabaseAuth.mjs";

const router = Router();

// Comprehensive IPC/BNS Database
const IPC_SECTIONS = [
  // Offences Against Human Body
  { section: "302", bns: "101", title: "Murder", category: "Offences Against Human Body", punishment: "Death or imprisonment for life + fine", bailable: false, cognizable: true },
  { section: "304", bns: "105", title: "Culpable Homicide not amounting to Murder", category: "Offences Against Human Body", punishment: "Life imprisonment or up to 10 years + fine", bailable: false, cognizable: true },
  { section: "304A", bns: "106", title: "Causing death by negligence", category: "Offences Against Human Body", punishment: "Up to 2 years or fine or both", bailable: true, cognizable: true },
  { section: "304B", bns: "80", title: "Dowry death", category: "Offences Against Human Body", punishment: "7 years to life imprisonment", bailable: false, cognizable: true },
  { section: "306", bns: "108", title: "Abetment of suicide", category: "Offences Against Human Body", punishment: "Up to 10 years + fine", bailable: false, cognizable: true },
  { section: "307", bns: "109", title: "Attempt to murder", category: "Offences Against Human Body", punishment: "Up to 10 years + fine; life if hurt caused", bailable: false, cognizable: true },
  { section: "308", bns: "110", title: "Attempt to commit culpable homicide", category: "Offences Against Human Body", punishment: "Up to 3 years or fine or both", bailable: false, cognizable: true },
  { section: "319", bns: "114", title: "Hurt", category: "Offences Against Human Body", punishment: "Up to 1 year or fine up to ₹1000 or both", bailable: true, cognizable: false },
  { section: "320", bns: "114", title: "Grievous Hurt", category: "Offences Against Human Body", punishment: "Up to 7 years + fine", bailable: false, cognizable: true },
  { section: "323", bns: "115", title: "Voluntarily causing hurt", category: "Offences Against Human Body", punishment: "Up to 1 year or fine or both", bailable: true, cognizable: false },
  { section: "324", bns: "117", title: "Voluntarily causing hurt by dangerous weapons", category: "Offences Against Human Body", punishment: "Up to 3 years or fine or both", bailable: false, cognizable: true },
  { section: "325", bns: "116", title: "Voluntarily causing grievous hurt", category: "Offences Against Human Body", punishment: "Up to 7 years + fine", bailable: false, cognizable: true },
  { section: "326", bns: "118", title: "Voluntarily causing grievous hurt by dangerous weapons", category: "Offences Against Human Body", punishment: "Life or up to 10 years + fine", bailable: false, cognizable: true },
  { section: "354", bns: "74", title: "Assault or criminal force to woman with intent to outrage modesty", category: "Offences Against Women", punishment: "1 to 5 years + fine", bailable: false, cognizable: true },
  { section: "354A", bns: "75", title: "Sexual harassment", category: "Offences Against Women", punishment: "Up to 3 years or fine or both", bailable: false, cognizable: true },
  { section: "354B", bns: "76", title: "Assault with intent to disrobe", category: "Offences Against Women", punishment: "3 to 7 years + fine", bailable: false, cognizable: true },
  { section: "354C", bns: "77", title: "Voyeurism", category: "Offences Against Women", punishment: "1 to 3 years (first offence); 3 to 7 years (repeat)", bailable: false, cognizable: true },
  { section: "354D", bns: "78", title: "Stalking", category: "Offences Against Women", punishment: "Up to 3 years (first offence); up to 5 years (repeat)", bailable: false, cognizable: true },
  { section: "375", bns: "63", title: "Rape", category: "Offences Against Women", punishment: "7 years to life imprisonment + fine", bailable: false, cognizable: true },
  { section: "376", bns: "64", title: "Punishment for rape", category: "Offences Against Women", punishment: "10 years to life imprisonment + fine", bailable: false, cognizable: true },
  { section: "376A", bns: "66", title: "Rape causing death or persistent vegetative state", category: "Offences Against Women", punishment: "20 years to life imprisonment or death", bailable: false, cognizable: true },
  { section: "376D", bns: "70", title: "Gang rape", category: "Offences Against Women", punishment: "20 years to life imprisonment + fine", bailable: false, cognizable: true },
  // Property Offences
  { section: "378", bns: "303", title: "Theft", category: "Property Offences", punishment: "Up to 3 years or fine or both", bailable: false, cognizable: true },
  { section: "379", bns: "303", title: "Punishment for theft", category: "Property Offences", punishment: "Up to 3 years or fine or both", bailable: false, cognizable: true },
  { section: "380", bns: "305", title: "Theft in dwelling house", category: "Property Offences", punishment: "Up to 7 years + fine", bailable: false, cognizable: true },
  { section: "383", bns: "308", title: "Extortion", category: "Property Offences", punishment: "Up to 3 years or fine or both", bailable: false, cognizable: true },
  { section: "384", bns: "308", title: "Punishment for extortion", category: "Property Offences", punishment: "Up to 3 years or fine or both", bailable: false, cognizable: true },
  { section: "390", bns: "309", title: "Robbery", category: "Property Offences", punishment: "Up to 10 years + fine", bailable: false, cognizable: true },
  { section: "392", bns: "309", title: "Punishment for robbery", category: "Property Offences", punishment: "Up to 10 years + fine; up to 14 years on highway", bailable: false, cognizable: true },
  { section: "395", bns: "310", title: "Dacoity", category: "Property Offences", punishment: "Life or up to 10 years + fine", bailable: false, cognizable: true },
  { section: "406", bns: "316", title: "Criminal breach of trust", category: "Property Offences", punishment: "Up to 3 years or fine or both", bailable: false, cognizable: true },
  { section: "415", bns: "318", title: "Cheating", category: "Property Offences", punishment: "Up to 1 year or fine or both", bailable: false, cognizable: false },
  { section: "420", bns: "318", title: "Cheating and dishonestly inducing delivery of property", category: "Property Offences", punishment: "Up to 7 years + fine", bailable: false, cognizable: true },
  { section: "425", bns: "324", title: "Mischief", category: "Property Offences", punishment: "Up to 3 months or fine or both", bailable: true, cognizable: false },
  { section: "441", bns: "329", title: "Criminal trespass", category: "Property Offences", punishment: "Up to 3 months or fine up to ₹500 or both", bailable: true, cognizable: false },
  { section: "447", bns: "329", title: "Punishment for criminal trespass", category: "Property Offences", punishment: "Up to 3 months or fine up to ₹500 or both", bailable: true, cognizable: false },
  // Public Order
  { section: "141", bns: "189", title: "Unlawful assembly", category: "Public Order", punishment: "Up to 6 months or fine or both", bailable: true, cognizable: true },
  { section: "143", bns: "191", title: "Punishment for unlawful assembly", category: "Public Order", punishment: "Up to 6 months or fine or both", bailable: true, cognizable: true },
  { section: "147", bns: "191", title: "Rioting", category: "Public Order", punishment: "Up to 2 years or fine or both", bailable: false, cognizable: true },
  { section: "148", bns: "192", title: "Rioting with deadly weapon", category: "Public Order", punishment: "Up to 3 years or fine or both", bailable: false, cognizable: true },
  { section: "153A", bns: "196", title: "Promoting enmity between different groups", category: "Public Order", punishment: "Up to 3 years or fine or both", bailable: false, cognizable: true },
  // Against State
  { section: "124A", bns: "152", title: "Sedition (Waging war against state)", category: "Against State", punishment: "Life imprisonment or up to 3 years + fine", bailable: false, cognizable: true },
  // Fraud & Documents
  { section: "463", bns: "336", title: "Forgery", category: "Fraud & Documents", punishment: "Up to 2 years or fine or both", bailable: false, cognizable: false },
  { section: "465", bns: "336", title: "Punishment for forgery", category: "Fraud & Documents", punishment: "Up to 2 years or fine or both", bailable: false, cognizable: false },
  { section: "468", bns: "340", title: "Forgery for purpose of cheating", category: "Fraud & Documents", punishment: "Up to 7 years + fine", bailable: false, cognizable: true },
  { section: "471", bns: "341", title: "Using as genuine a forged document", category: "Fraud & Documents", punishment: "Same as for forgery", bailable: false, cognizable: true },
  // Matrimonial
  { section: "498A", bns: "85", title: "Cruelty by husband or relatives", category: "Matrimonial", punishment: "Up to 3 years + fine", bailable: false, cognizable: true },
  { section: "494", bns: "82", title: "Bigamy", category: "Matrimonial", punishment: "Up to 7 years + fine", bailable: false, cognizable: false },
  { section: "495", bns: "83", title: "Bigamy with concealment of former marriage", category: "Matrimonial", punishment: "Up to 10 years + fine", bailable: false, cognizable: false },
  // Cyber Offences (IT Act 2000)
  { section: "66", bns: "IT Act", title: "Computer related offences (IT Act)", category: "Cyber Offences", punishment: "Up to 3 years or fine up to ₹5 lakh or both", bailable: false, cognizable: true },
  { section: "66A", bns: "Struck Down", title: "Offensive messages (Struck down by SC in Shreya Singhal v UOI 2015)", category: "Cyber Offences", punishment: "Struck down as unconstitutional", bailable: true, cognizable: false },
  { section: "66C", bns: "IT Act", title: "Identity theft (IT Act)", category: "Cyber Offences", punishment: "Up to 3 years + fine up to ₹1 lakh", bailable: false, cognizable: true },
  { section: "66D", bns: "IT Act", title: "Cheating by personation using computer (IT Act)", category: "Cyber Offences", punishment: "Up to 3 years + fine up to ₹1 lakh", bailable: false, cognizable: true },
  { section: "67", bns: "IT Act", title: "Publishing obscene material online (IT Act)", category: "Cyber Offences", punishment: "Up to 3 years + fine up to ₹5 lakh (first); up to 5 years (repeat)", bailable: false, cognizable: true },
  // Bail Sections (CrPC/BNSS)
  { section: "436", bns: "478 BNSS", title: "Bail in bailable offences (CrPC)", category: "Bail Provisions", punishment: "N/A — Right to bail", bailable: true, cognizable: false },
  { section: "437", bns: "480 BNSS", title: "Bail in non-bailable offences (CrPC)", category: "Bail Provisions", punishment: "N/A — Discretionary bail", bailable: false, cognizable: true },
  { section: "438", bns: "482 BNSS", title: "Anticipatory bail (CrPC)", category: "Bail Provisions", punishment: "N/A — Anticipatory bail", bailable: false, cognizable: true },
  { section: "439", bns: "483 BNSS", title: "Special powers of High Court regarding bail", category: "Bail Provisions", punishment: "N/A — High Court bail", bailable: false, cognizable: true },
  { section: "482", bns: "528 BNSS", title: "Inherent powers of High Court to quash FIR/proceedings", category: "Bail Provisions", punishment: "N/A — Quashing jurisdiction", bailable: false, cognizable: false },
];

router.get("/sections", requireAuth, (req, res) => {
  const { category, search } = req.query;
  let sections = IPC_SECTIONS;

  if (category) sections = sections.filter(s => s.category === category);
  if (search) {
    const q = search.toLowerCase();
    sections = sections.filter(s =>
      s.section.includes(q) || s.title.toLowerCase().includes(q) || s.bns.includes(q)
    );
  }

  const categories = [...new Set(IPC_SECTIONS.map(s => s.category))];
  res.json({ sections, total: sections.length, categories });
});

router.get("/search", requireAuth, (req, res) => {
  const { q } = req.query;
  if (!q) return res.status(400).json({ error: "Query parameter 'q' is required" });

  const query = q.toLowerCase();
  const results = IPC_SECTIONS.filter(s =>
    s.section.includes(query) || s.title.toLowerCase().includes(query) ||
    s.bns.includes(query) || s.category.toLowerCase().includes(query)
  );
  res.json({ results, total: results.length });
});

router.post("/explain", requireAuth, async (req, res) => {
  try {
    const { section, context } = req.body;
    if (!section) return res.status(400).json({ error: "section is required" });

    const sectionData = IPC_SECTIONS.find(s => s.section === section || s.bns === section);
    const sectionInfo = sectionData
      ? `IPC Section ${sectionData.section} (BNS ${sectionData.bns}): ${sectionData.title} — ${sectionData.punishment}`
      : `Section ${section}`;

    const apiKey = process.env.SAMBANOVA_API_KEY;
    if (!apiKey) throw new Error("SAMBANOVA_API_KEY not configured");

    const response = await fetch("https://api.sambanova.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json",
        
        
      },
      body: JSON.stringify({
        model: process.env.SAMBANOVA_MODEL || "Meta-Llama-3.3-70B-Instruct",
        messages: [
          { role: "system", content: "You are an expert in Indian criminal law. Explain legal sections clearly for advocates." },
          { role: "user", content: `Explain ${sectionInfo} in detail. Include: exact text, ingredients of the offence, punishment, bailable/non-bailable status, landmark Supreme Court judgments, practical application, and defence strategies.${context ? ` Context: ${context}` : ""}` },
        ],
        max_tokens: 2000,
        temperature: 0.2,
      }),
    });

    const result = await response.json();
    res.json({
      section: sectionData,
      explanation: result.choices[0]?.message?.content || "",
      model: result.model,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
