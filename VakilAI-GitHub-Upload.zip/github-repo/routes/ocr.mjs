/**
 * OCR Routes — Document scanning and text extraction
 * POST /api/ocr/scan         — Scan image/PDF and extract text
 * POST /api/ocr/analyze      — Analyze extracted text for legal entities
 * POST /api/incident/analyze — Map incident to IPC sections
 * POST /api/documents/export — Export document in Indian judiciary format
 */

import { Router } from "express";
import { requireAuth } from "../middleware/supabaseAuth.mjs";
import multer from "multer";
import { join } from "path";
import { mkdir } from "fs/promises";
import { existsSync } from "fs";
import { extractTextFromImage, analyzeExtractedText } from "../services/ocr.mjs";
import { analyzeIncidentToIPC } from "../services/incidentAnalysis.mjs";
import { generateAffidavit, generatePlaint, generateBailApplication, generateFIRComplaint, exportToWord, exportToText } from "../services/documentExport.mjs";

const router = Router();

// Configure multer for file uploads
const uploadDir = join(process.cwd(), "uploads");
if (!existsSync(uploadDir)) {
  await mkdir(uploadDir, { recursive: true });
}

const upload = multer({
  dest: uploadDir,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
  fileFilter: (req, file, cb) => {
    const allowed = ["image/jpeg", "image/png", "image/tiff", "application/pdf"];
    if (allowed.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error("Only JPG, PNG, TIFF, and PDF files are allowed"));
    }
  },
});

// ─── OCR Scan Route ───────────────────────────────────────────────────────────
router.post("/scan", requireAuth, upload.single("document"), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: "No file uploaded" });
    }

    const { language = "eng" } = req.body;
    const filepath = req.file.path;

    console.log(`[OCR] Scanning file: ${filepath}, language: ${language}`);

    // Extract text using Tesseract
    const ocrResult = await extractTextFromImage(filepath, language);

    // Analyze extracted text
    const analysis = analyzeExtractedText(ocrResult.text);

    res.json({
      success: true,
      extracted: {
        text: ocrResult.text,
        confidence: ocrResult.confidence,
        wordsDetected: ocrResult.wordsDetected,
      },
      analysis: {
        totalLines: analysis.totalLines,
        totalWords: analysis.totalWords,
        dates: analysis.dates,
        sections: analysis.sections,
        names: analysis.names,
        keyPhrases: analysis.keyPhrases,
        hasDatePatterns: analysis.hasDatePatterns,
        hasSectionPatterns: analysis.hasSectionPatterns,
      },
    });
  } catch (err) {
    console.error("[OCR Error]", err);
    res.status(500).json({ error: err.message });
  }
});

// ─── Incident to IPC Analysis ─────────────────────────────────────────────────
router.post("/incident/analyze", requireAuth, async (req, res) => {
  try {
    const { incidentDescription } = req.body;
    if (!incidentDescription?.trim()) {
      return res.status(400).json({ error: "incidentDescription is required" });
    }

    const apiKey = process.env.SAMBANOVA_API_KEY;
    if (!apiKey) {
      return res.status(503).json({ error: "AI analysis not configured" });
    }

    console.log("[Incident Analysis] Analyzing incident...");

    const analysis = await analyzeIncidentToIPC(incidentDescription, apiKey);

    res.json({
      success: true,
      analysis: {
        primaryCharges: analysis.primaryCharges,
        alternativeCharges: analysis.alternativeCharges,
        sections: analysis.sections,
        caselaw: analysis.caselaw,
        summary: analysis.analysis,
        confidence: analysis.confidence,
      },
    });
  } catch (err) {
    console.error("[Incident Analysis Error]", err);
    res.status(500).json({ error: err.message });
  }
});

// ─── Document Export Routes ───────────────────────────────────────────────────
router.post("/documents/export", requireAuth, async (req, res) => {
  try {
    const { documentType, data, format = "docx" } = req.body;

    if (!documentType || !["affidavit", "plaint", "bail", "fir"].includes(documentType)) {
      return res.status(400).json({
        error: "Invalid documentType",
        validTypes: ["affidavit", "plaint", "bail", "fir"],
      });
    }

    if (!data) {
      return res.status(400).json({ error: "data is required" });
    }

    let docxDocument;
    switch (documentType) {
      case "affidavit":
        docxDocument = generateAffidavit(data);
        break;
      case "plaint":
        docxDocument = generatePlaint(data);
        break;
      case "bail":
        docxDocument = generateBailApplication(data);
        break;
      case "fir":
        docxDocument = generateFIRComplaint(data);
        break;
    }

    const timestamp = Date.now();
    const filename = `${documentType}_${timestamp}.${format === "txt" ? "txt" : "docx"}`;

    let filepath;
    if (format === "txt") {
      filepath = exportToText(docxDocument, filename);
    } else {
      filepath = await exportToWord(docxDocument, filename);
    }

    res.json({
      success: true,
      message: `${documentType} exported successfully`,
      filename,
      format,
      downloadUrl: `/api/documents/download/${filename}`,
    });
  } catch (err) {
    console.error("[Document Export Error]", err);
    res.status(500).json({ error: err.message });
  }
});

// ─── Document Download Route ──────────────────────────────────────────────────
router.get("/download/:filename", requireAuth, (req, res) => {
  try {
    const filepath = join(process.cwd(), "exports", req.params.filename);

    // Security: prevent directory traversal
    if (!filepath.startsWith(join(process.cwd(), "exports"))) {
      return res.status(403).json({ error: "Access denied" });
    }

    res.download(filepath, req.params.filename, (err) => {
      if (err) {
        console.error("[Download Error]", err);
        res.status(500).json({ error: "Download failed" });
      }
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
