/**
 * Chat Routes — AI Legal Assistant via OpenRouter
 * GET    /api/chat/sessions               — List user's chat sessions
 * POST   /api/chat/sessions               — Create new session
 * DELETE /api/chat/sessions/:id           — Delete session
 * GET    /api/chat/sessions/:id/messages  — Get messages for session
 * POST   /api/chat/send                   — Send message, get AI response
 */

import { Router } from "express";
import { requireAuth } from "../middleware/supabaseAuth.mjs";
import { db } from "../server.mjs";

const router = Router();

const LEGAL_SYSTEM_PROMPT = `You are VakilAI, an expert Indian legal assistant and advocate with deep knowledge of:

CRIMINAL LAW:
- Indian Penal Code (IPC) 1860 and its replacement Bharatiya Nyaya Sanhita (BNS) 2023
- Code of Criminal Procedure (CrPC) 1973 and Bharatiya Nagarik Suraksha Sanhita (BNSS) 2023
- Indian Evidence Act 1872 and Bharatiya Sakshya Adhiniyam (BSA) 2023

CIVIL LAW:
- Code of Civil Procedure (CPC) 1908, Specific Relief Act 1963
- Transfer of Property Act 1882, Contract Act 1872

SPECIAL LAWS:
- PWDVA 2005, Dowry Prohibition Act 1961, POCSO 2012
- IT Act 2000, Motor Vehicles Act 1988, Consumer Protection Act 2019, RTI Act 2005

COURT PROCEDURE:
- Bail applications (Sections 436, 437, 438, 439 CrPC / BNSS)
- Anticipatory bail, Quashing petitions (Section 482 CrPC)
- Writ petitions (Article 226, 32)

DOCUMENT DRAFTING:
- FIR complaints, bail applications, vakalatnama
- Legal notices, plaints, written statements, affidavits

IMPORTANT RULES:
1. Always cite specific IPC/BNS section numbers with their titles
2. Mention both old IPC section AND new BNS equivalent when relevant
3. Reference landmark Supreme Court and High Court judgments when applicable
4. Use formal legal language appropriate for Indian courts
5. When drafting documents, use proper legal format
6. Always add a disclaimer that AI-generated content should be verified by a qualified advocate
7. Respond in the same language as the user (English or Marathi)`;

// ─── List Sessions ────────────────────────────────────────────────────────────
router.get("/sessions", requireAuth, async (req, res) => {
  try {
    const { data, error } = await db
      .from("chat_sessions")
      .select("id, title, created_at, updated_at")
      .eq("supabase_uid", req.user.uid)
      .order("updated_at", { ascending: false })
      .limit(50);

    if (error) throw new Error(error.message);
    res.json({ sessions: data });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── Create Session ───────────────────────────────────────────────────────────
router.post("/sessions", requireAuth, async (req, res) => {
  try {
    const { title = "New Conversation" } = req.body;

    const { data, error } = await db
      .from("chat_sessions")
      .insert({ supabase_uid: req.user.uid, title })
      .select()
      .single();

    if (error) throw new Error(error.message);
    res.status(201).json({ session: data });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── Delete Session ───────────────────────────────────────────────────────────
router.delete("/sessions/:id", requireAuth, async (req, res) => {
  try {
    const { error } = await db
      .from("chat_sessions")
      .delete()
      .eq("id", req.params.id)
      .eq("supabase_uid", req.user.uid);

    if (error) throw new Error(error.message);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── Get Messages ─────────────────────────────────────────────────────────────
router.get("/sessions/:id/messages", requireAuth, async (req, res) => {
  try {
    const { data: session } = await db
      .from("chat_sessions")
      .select("id")
      .eq("id", req.params.id)
      .eq("supabase_uid", req.user.uid)
      .single();

    if (!session) return res.status(404).json({ error: "Session not found" });

    const { data, error } = await db
      .from("chat_messages")
      .select("id, role, content, created_at")
      .eq("session_id", req.params.id)
      .order("created_at", { ascending: true });

    if (error) throw new Error(error.message);
    res.json({ messages: data });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── Send Message & Get AI Response ──────────────────────────────────────────
router.post("/send", requireAuth, async (req, res) => {
  try {
    const { sessionId, message, language = "english" } = req.body;
    if (!sessionId || !message) {
      return res.status(400).json({ error: "sessionId and message are required" });
    }

    // Verify session ownership
    const { data: session } = await db
      .from("chat_sessions")
      .select("id")
      .eq("id", sessionId)
      .eq("supabase_uid", req.user.uid)
      .single();

    if (!session) return res.status(404).json({ error: "Session not found" });

    // Save user message
    await db.from("chat_messages").insert({
      session_id: sessionId,
      supabase_uid: req.user.uid,
      role: "user",
      content: message,
    });

    // Get conversation history (last 20 messages)
    const { data: history } = await db
      .from("chat_messages")
      .select("role, content")
      .eq("session_id", sessionId)
      .order("created_at", { ascending: true })
      .limit(20);

    // Language instruction
    const langInstruction = language === "marathi"
      ? "\n\nIMPORTANT: Respond in Marathi (मराठी) using proper legal Marathi terminology."
      : "";

    // Call OpenRouter AI
    const apiKey = process.env.SAMBANOVA_API_KEY;
    if (!apiKey) throw new Error("SAMBANOVA_API_KEY not configured");

    const aiResponse = await fetch("https://api.sambanova.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json",
        
        
      },
      body: JSON.stringify({
        model: process.env.SAMBANOVA_MODEL || "Meta-Llama-3.3-70B-Instruct",
        messages: [
          { role: "system", content: LEGAL_SYSTEM_PROMPT + langInstruction },
          ...(history || []),
        ],
        max_tokens: 4000,
        temperature: 0.3,
      }),
    });

    if (!aiResponse.ok) {
      const err = await aiResponse.json().catch(() => ({}));
      throw new Error(err?.error?.message || `OpenRouter error: ${aiResponse.status}`);
    }

    const result = await aiResponse.json();
    const assistantMessage = result.choices[0]?.message?.content || "I couldn't generate a response. Please try again.";

    // Save assistant message
    await db.from("chat_messages").insert({
      session_id: sessionId,
      supabase_uid: req.user.uid,
      role: "assistant",
      content: assistantMessage,
    });

    // Update session title if first message
    const { count } = await db
      .from("chat_messages")
      .select("id", { count: "exact" })
      .eq("session_id", sessionId);

    if (count <= 2) {
      const title = message.length > 60 ? message.substring(0, 60) + "..." : message;
      await db.from("chat_sessions").update({ title }).eq("id", sessionId);
    }

    // Log usage
    await db.from("usage_logs").insert({
      supabase_uid: req.user.uid,
      action: "chat",
      tokens_used: result.usage?.total_tokens || 0,
      model_used: result.model,
    });

    res.json({
      message: assistantMessage,
      sessionId,
      model: result.model,
      tokensUsed: result.usage?.total_tokens || 0,
    });
  } catch (err) {
    console.error("[Chat Send]", err);
    res.status(500).json({ error: err.message });
  }
});

export default router;
