/**
 * Auth Routes — Supabase Authentication
 * POST /api/auth/sync     — Sync Supabase user to users table
 * GET  /api/auth/me       — Get current user profile
 * POST /api/auth/logout   — Logout (informational)
 * POST /api/auth/set-role — Admin: set user role
 */

import { Router } from "express";
import { requireAuth, requireAdmin, setUserRole } from "../middleware/supabaseAuth.mjs";
import { db } from "../server.mjs";

const router = Router();

// ─── Sync Supabase user to public.users table ─────────────────────────────────
router.post("/sync", requireAuth, async (req, res) => {
  try {
    const { uid, email, name } = req.user;

    const { data, error } = await db
      .from("users")
      .upsert(
        { supabase_uid: uid, email, name, last_signed_in: new Date().toISOString() },
        { onConflict: "supabase_uid", ignoreDuplicates: false }
      )
      .select("id, supabase_uid, email, name, role, created_at")
      .single();

    if (error) throw new Error(error.message);

    res.json({ success: true, user: data });
  } catch (err) {
    console.error("[Auth Sync]", err);
    res.status(500).json({ error: "Failed to sync user", message: err.message });
  }
});

// ─── Get current user ─────────────────────────────────────────────────────────
router.get("/me", requireAuth, async (req, res) => {
  try {
    const { data, error } = await db
      .from("users")
      .select("id, supabase_uid, email, name, role, created_at, last_signed_in")
      .eq("supabase_uid", req.user.uid)
      .single();

    if (error || !data) {
      return res.status(404).json({ error: "User not found. Please sync first." });
    }

    res.json({ user: data });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── Logout (informational) ───────────────────────────────────────────────────
router.post("/logout", requireAuth, (req, res) => {
  // Supabase tokens are JWTs — call supabase.auth.signOut() on the client
  res.json({ success: true, message: "Please call supabase.auth.signOut() on the client." });
});

// ─── Set user role (admin only) ───────────────────────────────────────────────
router.post("/set-role", requireAuth, requireAdmin, async (req, res) => {
  try {
    const { uid, role } = req.body;
    if (!uid || !["user", "admin"].includes(role)) {
      return res.status(400).json({ error: "Invalid uid or role. Role must be 'user' or 'admin'." });
    }

    await setUserRole(uid, role);
    res.json({ success: true, message: `User ${uid} role updated to ${role}` });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
