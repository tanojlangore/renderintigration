/**
 * VakilAI Backend Server
 * Express + Supabase Auth + Supabase PostgreSQL + OpenRouter
 * Deployed on Render.com
 *
 * Start: node server.mjs
 */

import express from "express";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import { createClient } from "@supabase/supabase-js";
import dotenv from "dotenv";
import { fileURLToPath } from "url";
import { dirname, join } from "path";

// Routes
import authRoutes from "./routes/auth.mjs";
import casesRoutes from "./routes/cases.mjs";
import documentsRoutes from "./routes/documents.mjs";
import chatRoutes from "./routes/chat.mjs";
import ipcRoutes from "./routes/ipc.mjs";
import subscriptionRoutes from "./routes/subscriptions.mjs";
import adminRoutes from "./routes/admin.mjs";
import ocrRoutes from "./routes/ocr.mjs";

const __dirname = dirname(fileURLToPath(import.meta.url));

// ─── Load Environment Variables ───────────────────────────────────────────────
dotenv.config({ path: join(__dirname, ".env") });

const PORT = process.env.PORT || 5000;
const NODE_ENV = process.env.NODE_ENV || "production";
const FRONTEND_URL = process.env.FRONTEND_URL || "https://vakilai-platform.vercel.app";

// ─── Supabase Admin DB Client ─────────────────────────────────────────────────
// This client bypasses RLS — safe for server-side only
export const db = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY,
  { auth: { autoRefreshToken: false, persistSession: false } }
);

// ─── App Setup ────────────────────────────────────────────────────────────────
const app = express();

// Security headers
app.use(helmet({
  contentSecurityPolicy: false,
  crossOriginEmbedderPolicy: false,
}));

// CORS — allow frontend domain
app.use(cors({
  origin: [
    FRONTEND_URL,
    "https://vakilai-platform.vercel.app",
    /localhost:\d+/,
  ],
  credentials: true,
  methods: ["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"],
  allowedHeaders: ["Content-Type", "Authorization"],
}));

// Body parsing
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true, limit: "10mb" }));

// ─── Rate Limiting ────────────────────────────────────────────────────────────
const globalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 200,
  message: { error: "Too many requests. Please try again later." },
  standardHeaders: true,
  legacyHeaders: false,
});

const aiLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 10,
  message: { error: "AI request limit reached. Please wait 1 minute." },
  keyGenerator: (req) => req.user?.uid || req.ip,
});

app.use("/api/", globalLimiter);
app.use("/api/chat/", aiLimiter);
app.use("/api/documents/generate", aiLimiter);
app.use("/api/ipc/explain", aiLimiter);

// ─── Health Check ─────────────────────────────────────────────────────────────
app.get("/api/health", async (req, res) => {
  try {
    // Quick DB connectivity test
    const { error } = await db.from("users").select("id").limit(1);
    res.json({
      status: "healthy",
      database: error ? "error" : "connected",
      version: "2.2.0",
      timestamp: new Date().toISOString(),
    });
  } catch (err) {
    res.status(503).json({ status: "unhealthy", database: "disconnected", error: err.message });
  }
});

// ─── API Routes ───────────────────────────────────────────────────────────────
app.use("/api/auth", authRoutes);
app.use("/api/cases", casesRoutes);
app.use("/api/documents", documentsRoutes);
app.use("/api/chat", chatRoutes);
app.use("/api/ipc", ipcRoutes);
app.use("/api/subscriptions", subscriptionRoutes);
app.use("/api/admin", adminRoutes);
app.use("/api/ocr", ocrRoutes);

// ─── Global Error Handler ─────────────────────────────────────────────────────
app.use((err, req, res, _next) => {
  console.error("[Server Error]", err);
  res.status(err.status || 500).json({
    error: err.message || "Internal server error",
    ...(NODE_ENV === "development" && { stack: err.stack }),
  });
});

// ─── Start Server ─────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`✅ VakilAI API running on port ${PORT} [${NODE_ENV}]`);
  console.log(`   Health: http://localhost:${PORT}/api/health`);
  console.log(`   Supabase: ${process.env.SUPABASE_URL}`);
});

export default app;
